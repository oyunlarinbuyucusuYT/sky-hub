--[[
	code generated using luamin.js, Herrtt#3868
--]]

---Credits: v3rm Gogogamer61

_, Protected_by_MoonSecV2, Discord = 'discord.gg/gQEH2uZxUk'


, nil, nil;
(function()
	_msec = (function(n, e, o)
		local J = e["                "];
		local G = o[n[(-87 + 755)]][n["               "]];
		local x = (72 - 68) / (((16478 / (233 + -79)) - 87) + -#'CockAndBallTorture')
		local r = (-#'edp445 what are you doing to my 3 year old son' + (82 + (-#[[BluntMan420 Was Here]] + (((-688576 / 212) + -#"zNugget is dad") / 233)))) - (5 + -#{
			{},
			'nil',
			73;
			28
		})
		local p = o[n[(328 - 203)]][n["   ​            "]];
		local S = ((193 + (-888 / 8)) - 81) + (-#'Rape me daddy' + (2370 / 158))
		local O = o[n[(-#'Hard Sex with iPipeh' + (664 + -121))]][n[" ​​     "]]
		local a = (-#'big hard cock' + (-85 + 100)) - (((-#"cock in my ass" + (93408 / (135 - 103))) / 83) + -#[[mee6 what are you doing to my wife]])
		local s = (-#{
			1,
			157,
			12,
			(function()
				return {
					','
				}
			end)()
		} + 7)
		local h = (-#{
			(function()
				return #{
					('fhHPkl'):find("\72")
				} > 0 and 1 or 0
			end);
			42,
			1,
			(function()
				return {
					','
				}
			end)(),
			","
		} + 8)
		local U = (690 / (-123 + (-#{
			(function()
				return #{
					('fmMLoL'):find("\77")
				} > 0 and 1 or 0
			end);
			28,
			96;
			'nil';
			","
		} + 358)))
		local w = (219 / (140 + (((-14 - 46) + -#[[xenny its znugget please respond]]) + 25)))
		local c = (74 - ((-#{
			22,
			'}';
			1,
			",",
			(function()
				return #{
					('khBpkh'):find("\66")
				} > 0 and 1 or 0
			end)
		} + 4904) / 69))
		local B = (-107 + (3520 / ((-#"cock in my ass" + (-95 + (-#'This is working now' + (611 - 351)))) - 100)))
		local H = (-52 + (-#'IPIPEH ILOVE YOU AAAAA' + (202 - ((-85 + 10005) / 80))))
		local g = ((((2990844 / (387 - 206)) / 162) - 85) + -#"iPipeh My God")
		local F = ((-9576 / ((-17 + 127) + -34)) + 130)
		local M = (-#{
			(function()
				return {
					','
				}
			end)();
			62;
			1;
			'}',
			'nil'
		} + 9)
		local P = (140 / ((((887 + -72) - 441) - 196) - 143))
		local v = (-#"deobfuscated" + (3856 / (24582 / (107 + -#{
			81,
			81,
			{};
			(function()
				return #{
					('kKFHLl'):find("\70")
				} > 0 and 1 or 0
			end);
			","
		}))))
		local N = (-#[[Factual]] + (((2920 - (-103 + 1586)) - 762) / 75))
		local b = (-#{
			{},
			27;
			84,
			(function()
				return {
					','
				}
			end)(),
			(function()
				return {
					','
				}
			end)()
		} + 7)
		local f = (-#'iPipeh My God' + ((((-44571 / 83) + -57) / 18) + 48))
		local u = (((-#{
			(function()
				return {
					','
				}
			end)();
			'nil',
			",";
			'nil';
			(function()
				return {
					','
				}
			end)();
			79,
			'}'
		} + 165) - 138) + -#"iam u Furry iPipeh")
		local k = (7 + -#{
			129,
			'}',
			(function()
				return #{
					('oFpFhm'):find("\112")
				} > 0 and 1 or 0
			end),
			'nil',
			129
		})
		local t = ((31 - (17860 / (242 + -#{
			47;
			47;
			",";
			",";
			1;
			47,
			1
		}))) + 47)
		local T = n[(-#{
			'nil',
			27,
			'}';
			",";
			",",
			27;
			129
		} + 1391)];
		local L = o[n[(-#{
			1;
			'}',
			'nil';
			(function()
				return {
					','
				}
			end)();
			'nil',
			'}'
		} + 131)]][n["                   "]];
		local j = o[(function(e)
			return type(e):sub(1, 1) .. '\101\116'
		end)('​     ​ ') .. '\109\101' .. ('\116\97' or '        ') .. n[(1151 - 628)]];
		local A = o[n[((-2414 / 142) + 540)]][n["         "]];
		local m = ((806 / 31) + -#[[azulx eats squids RUNNNN]]) - (((3 + (-4 - 49)) + 61) + -#[[no thanks]])
		local D = (-#'big black sins' + ((6097 - (6292 - 3187)) / 187)) - (502 / 251)
		local z = o[n[(-#{
			80;
			61,
			'}'
		} + 128)]][n["         ​        "]];
		local e = function(n, e)
			return n .. e
		end
		local y = (-60 + 64) * ((4366 / ((-#'This is working now' + (-25 + 403)) - 241)) - 33)
		local W = o[n["           "]];
		local d = (420 / 210) * (188 + (((-44 + 69) + -60) + -#"everybody needs salvation"))
		local I = (113664 / (18204 / 164)) * ((149 - (-#"Never gonna give u up" + ((22940 / 4) / 37))) + -#"Rape me daddy")
		local R = ((12824 / (-#'big black sins' + (-47 + 117))) - 177)
		local _ = (-#"amena jumping" + ((-#"420Script Was Here" + (140244 / (94 + -36))) / 160)) * (123 - 121)
		local C = o[n["            ​  "]] or o[n[(1122 - 599)]][n["            ​  "]];
		local i = (567 - ((787 - (-26 + 457)) + -#[[guys Please proceed to translate D to Sinhala]]))
		local n = o[n["           ​  ​    "]];
		local A = (function(d)
			local i, o = 3, 16
			local n = {
				j = {},
				v = {}
			}
			local l = -a
			local e = o + r
			while true do
				n[d:sub(e, (function()
					e = i + e
					return e - r
				end)())] = (function()
					l = l + a
					return l
				end)()
				if l == (y - a) then
					l = ""
					o = m
					break
				end
			end
			local l = #d
			while e < l + r do
				n.v[o] = d:sub(e, (function()
					e = i + e
					return e - r
				end)())
				o = o + a
				if o % x == m then
					o = D
					A(n.j, (z((n[n.v[D]] * y) + n[n.v[a]])))
				end
			end
			return O(n.j)
		end)("..:::MoonSec::..                ​                                ​                          ​               ​     ​  ​                                           ​    ​           ​        ​                ​                                  ​                                                                         ​                                                                ​                           ​       ​    ​           ​         ​          ​       ​                               ​                        ​                     ​                 ​                                    ​                       ​                                   ​                  ​                                                                                 ​                                ​                      ​                                              ​                                                                                                                            ​           ​                              ​            ​                                   ​         ​   ​ ​                                              ​   ​              ​            ​                                                                      ​     ​   ​                                          ​​                          ​   ​  ​​                ​ ​       ​              ​            ​                                             ​                                                   ​                            ​                ​                                               ​              ​                    ​      ​                 ​          ​                    ​                     ​​                                                    ​                                         ​                                      ​                                                                    ​        ​                             ​            ​                                                         ​                              ​ ​                                        ​   ​ ​              ​             ​        ​                  ​           ​                                                       ​                                                                ​   ​                ​                        ​                     ​                                           ​                                                            ​  ​     ​     ​                       ​                ​                                          ​       ​                            ​                       ​                                         ​                ​                ​                                                                      ​​               ​   ​                    ​                                                  ​     ​                  ​                     ​      ​                     ​   ​ ​                                                                   ​ ​    ​                  ​                              ​                     ​         ​        ​       ​               ​​        ​         ​         ​    ​                                                             ​          ​                 ​                                    ​   ​     ​           ​                          ​      ​                                 ​                                                        ​                                  ​                                ​                                    ​                                                      ​            ​  ​                                         ​                  ​                ​                               ​                 ​     ​                                  ​                                     ​ ​                            ​     ​                                    ​                       ​                                                                  ​                   ​                                                                            ​            ​                                     ​                          ​                                                                                ​                ​                  ​                                                                                    ​                       ​    ​   ​     ​                     ​              ​                                    ​  ​                                 ​                                 ​                                    ​                                    ​                                     ​               ​                                    ​                                    ​                                      ​            ​                         ​                                             ​​                            ​                       ​                ​                                                                                     ​    ​   ​                         ​                                   ​                                       ​                                 ​​                                                                         ​                  ​                               ​                                     ​     ​                                ​                                     ​                                     ​                                                                    ​                                  ​ ​            ​    ​                                  ​                                   ​                                   ​      ​                          ​​                                                                  ");
		local O = (39 + -#{
			(function()
				return #{
					('ffHmbl'):find("\72")
				} > 0 and 1 or 0
			end),
			",";
			92,
			1,
			1
		})
		local l = 84
		local o = a;
		local n = {}
		n = {
			[(141 / 141)] = function()
				local r, a, n, e = p(A, o, o + S);
				o = o + _;
				l = (l + (O * _)) % i;
				return (((e + l - (O) + d * (_ * x)) % d) * ((x * I) ^ x)) + (((n + l - (O * x) + d * (x ^ S)) % i) * (d * i)) + (((a + l - (O * S) + I) % i) * d) + ((r + l - (O * _) + I) % i);
			end,
			[(97 - 95)] = function(e, e, e)
				local e = p(A, o, o);
				o = o + r;
				l = (l + (O)) % i;
				return ((e + l - (O) + I) % d);
			end,
			[((120 - 91) - 26)] = function()
				local e, n = p(A, o, o + x);
				l = (l + (O * x)) % i;
				o = o + x;
				return (((n + l - (O) + d * (x * _)) % d) * i) + ((e + l - (O * x) + i * (x ^ S)) % d);
			end,
			[(-39 + (106 + -63))] = function(o, e, n)
				if n then
					local e = (o / x ^ (e - a)) % x ^ ((n - r) - (e - a) + r);
					return e - e % a;
				else
					local e = x ^ (e - r);
					return (o % (e + e) >= e) and a or D;
				end;
			end,
			[((1900 / 100) + -#'big black sins')] = function()
				local o = n[(36 - 35)]();
				local e = n[(102 + -101)]();
				local c = a;
				local l = (n[((-116 + 137) + -#[[Candyman was here]])](e, r, y + _) * (x ^ (y * x))) + o;
				local o = n[(748 / 187)](e, 21, 31);
				local e = ((-a) ^ n[(-#[[iPipeh I Love You]] + (3969 / 189))](e, 32));
				if (o == D) then
					if (l == m) then
						return e * D;
					else
						o = r;
						c = m;
					end;
				elseif (o == (d * (x ^ S)) - r) then
					return (l == D) and (e * (r / m)) or (e * (D / m));
				end;
				return G(e, o - ((i * (_)) - a)) * (c + (l / (x ^ R)));
			end,
			[((-57 + 76) + -#'amena jumping')] = function(e, x, x)
				local x;
				if (not e) then
					e = n[(29 - 28)]();
					if (e == D) then
						return '';
					end;
				end;
				x = L(A, o, o + e - a);
				o = o + e;
				local e = ''
				for n = r, #x do
					e = T(e, z((p(L(x, n, n)) + l) % i))
					l = (l + O) % d
				end
				return e;
			end
		}
		local function L(...)
			return {
				...
			}, W('#', ...)
		end
		local function I()
			local h = {};
			local b = {};
			local e = {};
			local k = {
				h,
				b,
				nil,
				e
			};
			local o = {}
			local w = (310 - 216)
			local e = {
				[(74 + -73)] = (function(e)
					return not(#e == n[(110 - (185 + -77))]())
				end),
				[(96 - 96)] = (function(e)
					return n[((75 - 55) + -#"Nitro Activated")]()
				end),
				[((96 - 81) + -#[[KenaiiIsGay]])] = (function(e)
					return n[(53 - 47)]()
				end),
				[(24 - 22)] = (function(e)
					local o = n[(133 + -127)]()
					local n = ''
					local e = 1
					for l = 1, #o do
						e = (e + w) % i
						n = T(n, z((p(o:sub(l, l)) + e) % d))
					end
					return n
				end)
			};
			local l = n[(6 / 6)]()
			for l = 1, l do
				local n = n[(43 - 41)]();
				local d;
				local e = e[n % (1760 / 40)];
				o[l] = e and e({});
			end;
			for b = 1, n[(25 - 24)]() do
				local e = n[(222 / 111)]();
				if (n[(-#[[Fuck nigger wank shit dipshit cunt bullshit fuckyou hoe lol]] + (3528 / 56))](e, a, r) == m) then
					local i = n[(31 - 27)](e, x, S);
					local l = n[(45 + -41)](e, _, x + _);
					local e = {
						n[(273 / 91)](),
						n[(564 / 188)](),
						nil,
						nil
					};
					local d = {
						[(-#'tonka' + ((193 + -97) - 91))] = function()
							e[c] = n[(30 - 27)]();
							e[v] = n[(309 / 103)]();
						end,
						[(33 / 33)] = function()
							e[s] = n[(84 / (193 - 109))]();
						end,
						[(48 - (-#'big hard cock' + (-116 + 175)))] = function()
							e[c] = n[(-#"iPipeh My God" + (97 + -83))]() - (x ^ y)
						end,
						[(116 + -113)] = function()
							e[c] = n[((150 - 137) + -#"deobfuscated")]() - (x ^ y)
							e[H] = n[(49 + -46)]();
						end
					};
					d[i]();
					if (n[(86 + -82)](l, r, a) == r) then
						e[N] = o[e[t]]
					end
					if (n[((-103 + 124) + -#"911WasAnInsideJob")](l, x, x) == a) then
						e[U] = o[e[c]]
					end
					if (n[(524 / 131)](l, S, S) == r) then
						e[F] = o[e[M]]
					end
					h[b] = e;
				end
			end;
			k[3] = n[(2 / 1)]();
			for e = r, n[(-37 + 38)]() do
				b[e - r] = I();
			end;
			return k;
		end;
		local function D(n, _, O)
			local o = n[x];
			local S = n[S];
			local n = n[a];
			return (function(...)
				local m = {};
				local i = n;
				local l = a;
				local y = o;
				local A = W('#', ...) - r;
				local o = {};
				local p = L
				local d = {
					...
				};
				local I = {};
				local n = S;
				local S = a
				S *= -1
				local S = S;
				for e = 0, A do
					if (e >= n) then
						I[e - n] = d[e + r];
					else
						o[e] = d[e + a];
					end;
				end;
				local n = A - n + a
				local n;
				local d;
				local alreadyGot = {};
				while true do
					n = i[l];
					d = n[(-71 + 72)];
					e = (3568768)
						
						for _,r in pairs(i) do
							if (type(r) == "table") then
								for i,v in pairs(r) do
									local ItAintGot = true;
										for _,item in ipairs(alreadyGot) do
											if (item == v) then
												ItAintGot = false;
												end;
											end;
										if ItAintGot then
											table.insert(alreadyGot, v);
											print(i,v);
											end;
										end;
									end;
								end;
					while ((193 - 149) + -#"test 123") >= d do
						e -= e
						e = (8362992)
						while d <= (2856 / 168) do
							e -= e
							e = (1481844)
							while d <= (896 / 112) do
								e -= e
								e = (14961199)
								while (252 / 84) >= d do
									e -= e
									e = (1243242)
									while (191 / 191) >= d do
										e -= e
										e = (474830)
										while (-#"looadstring" + (94 - 83)) < d do
											e -= e
											if (o[n[t]] ~= o[n[M]]) then
												l = l + r;
											else
												l = n[w];
											end;
											break
										end
										while (e) / ((4663 - 2358)) == 206 do
											o[n[b]] = n[U];
											break
										end;
										break;
									end
									while (e) / (((-50 + 120632) / 203)) == 2093 do
										e = (5822632)
										while (-#[[Hard Sex with iPipeh]] + (110 - 88)) < d do
											e -= e
											o[n[k]] = #o[n[c]];
											break
										end
										while (e) / ((153995 / 95)) == 3592 do
											local l = n[w];
											local e = o[l]
											for n = l + 1, n[P] do
												e = e .. o[n];
											end;
											o[n[b]] = e;
											break
										end;
										break;
									end
									break;
								end
								while (e) / ((-#'Rivers Cuomo' + (144115 / 37))) == 3853 do
									e = (3752325)
									while (28 + -23) >= d do
										e -= e
										e = (6921200)
										while d > (77 - 73) do
											e -= e
											local e = {
												o,
												n
											};
											e[r][e[x][b]] = e[a][e[x][v]] + e[r][e[x][w]];
											break
										end
										while 2288 == (e) / ((662475 / 219)) do
											l = n[c];
											break
										end;
										break;
									end
									while 1275 == (e) / (((-38 + -63) + 3044)) do
										e = (4944872)
										while ((-109 + 134) + -#[[I like gargling cum]]) >= d do
											e -= e
											local e = n[k];
											local a = o[e + 2];
											local d = o[e] + a;
											o[e] = d;
											if (a > 0) then
												if (d <= o[e + 1]) then
													l = n[w];
													o[e + 3] = d;
												end
											elseif (d >= o[e + 1]) then
												l = n[w];
												o[e + 3] = d;
											end
											break;
										end
										while (e) / ((197192 / 157)) == 3937 do
											e = (2969848)
											while (1211 / 173) < d do
												e -= e
												local e = n[u];
												local d = o[e]
												local a = o[e + 2];
												if (a > 0) then
													if (d > o[e + 1]) then
														l = n[w];
													else
														o[e + 3] = d;
													end
												elseif (d < o[e + 1]) then
													l = n[c];
												else
													o[e + 3] = d;
												end
												break
											end
											while (e) / ((-#"BluntMan420 Was Here" + (149292 / 116))) == 2344 do
												o[n[b]] = o[n[c]][n[P]];
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								break;
							end
							while 3068 == (e) / ((1058 - 575)) do
								e = (861588)
								while ((105 - 82) + -#[[dick cheese]]) >= d do
									e -= e
									e = (4303748)
									while ((2670 / 178) + -#'tonka') >= d do
										e -= e
										e = (213516)
										while d > ((3720 / 186) + -#"free trojan") do
											e -= e
											o[n[k]] = {};
											break
										end
										while (e) / ((706 - 382)) == 659 do
											o[n[N]] = o[n[U]][o[n[P]]];
											break
										end;
										break;
									end
									while (e) / ((1922 + -16)) == 2258 do
										e = (8040182)
										while (30 + -19) < d do
											e -= e
											o[n[f]] = _[n[U]];
											break
										end
										while 2911 == (e) / ((-#"911WasAnInsideJob" + (2824 + -45))) do
											_[n[h]] = o[n[b]];
											break
										end;
										break;
									end
									break;
								end
								while 1092 == (e) / (((6472 / 8) + -#'Thats what im saying')) do
									e = (2410075)
									while d <= (-#[[require]] + (128 + (-192 + 85))) do
										e -= e
										e = (725126)
										while (-123 + 136) < d do
											e -= e
											local e = n[b];
											local a = o[e + 2];
											local d = o[e] + a;
											o[e] = d;
											if (a > 0) then
												if (d <= o[e + 1]) then
													l = n[w];
													o[e + 3] = d;
												end
											elseif (d >= o[e + 1]) then
												l = n[w];
												o[e + 3] = d;
											end
											break
										end
										while (e) / ((357 + -118)) == 3034 do
											O[n[s]] = o[n[t]];
											break
										end;
										break;
									end
									while (e) / (((607563 / 187) + -#"cock in my ass")) == 745 do
										e = (1035362)
										while d <= (-#'free trojan' + (1066 / 41)) do
											e -= e
											if (o[n[f]] == o[n[g]]) then
												l = l + r;
											else
												l = n[h];
											end;
											break;
										end
										while (e) / ((2148 - 1085)) == 974 do
											e = (990600)
											while (59 + -43) < d do
												e -= e
												o[n[k]] = (n[U] ~= 0);
												l = l + r;
												break
											end
											while (e) / ((31800 / 53)) == 1651 do
												o[n[k]][o[n[w]]] = o[n[v]];
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								break;
							end
							break;
						end
						while (e) / ((3137 + -35)) == 2696 do
							e = (2388922)
							while (598 / (89 - 66)) >= d do
								e -= e
								e = (485604)
								while ((186 - 144) + -#[[Never gonna give u up]]) >= d do
									e -= e
									e = (736398)
									while d <= (((33325 / 215) + -#[[I hate women]]) + -124) do
										e -= e
										e = (5381539)
										while (133 - 115) < d do
											e -= e
											local e = n[b];
											local d = o[e]
											local a = o[e + 2];
											if (a > 0) then
												if (d > o[e + 1]) then
													l = n[B];
												else
													o[e + 3] = d;
												end
											elseif (d < o[e + 1]) then
												l = n[c];
											else
												o[e + 3] = d;
											end
											break
										end
										while (e) / ((74689 / 19)) == 1369 do
											if not o[n[f]] then
												l = l + r;
											else
												l = n[s];
											end;
											break
										end;
										break;
									end
									while (e) / ((-16 + 367)) == 2098 do
										e = (286936)
										while (((19538 - 9778) / 244) + -#"Hard Sex with iPipeh") < d do
											e -= e
											local e = n[u]
											o[e] = o[e](C(o, e + a, n[s]))
											break
										end
										while (e) / ((140264 / 197)) == 403 do
											if not o[n[u]] then
												l = l + r;
											else
												l = n[w];
											end;
											break
										end;
										break;
									end
									break;
								end
								while (e) / (((19152084 / 67) / 83)) == 141 do
									e = (2131024)
									while d <= (96 - (-#'Never gonna give u up' + (17014 / 181))) do
										e -= e
										e = (3450748)
										while d > (-#'Oliwka Brazil To Szef' + (113 - 70)) do
											e -= e
											do
												return o[n[t]]
											end
											break
										end
										while 1004 == (e) / ((-#"Bong" + (3502 + -61))) do
											do
												return o[n[t]]
											end
											break
										end;
										break;
									end
									while 742 == (e) / ((5791 - 2919)) do
										e = (6035760)
										while d <= ((92 - 55) + -#'fish was here') do
											e -= e
											local S;
											local d;
											local _;
											local e;
											o[n[k]] = O[n[h]];
											l = l + a;
											n = i[l];
											o[n[t]] = o[n[c]][n[v]];
											l = l + a;
											n = i[l];
											e = n[t];
											_ = o[n[c]];
											o[e + 1] = _;
											o[e] = _[n[H]];
											l = l + a;
											n = i[l];
											o[n[u]] = o[n[s]];
											l = l + a;
											n = i[l];
											o[n[t]] = o[n[B]];
											l = l + a;
											n = i[l];
											e = n[u]
											o[e] = o[e](C(o, e + a, n[U]))
											l = l + a;
											n = i[l];
											e = n[b];
											_ = o[n[w]];
											o[e + 1] = _;
											o[e] = _[n[P]];
											l = l + a;
											n = i[l];
											e = n[b]
											o[e] = o[e](o[e + r])
											l = l + a;
											n = i[l];
											d = {
												o,
												n
											};
											d[r][d[x][N]] = d[a][d[x][M]] + d[r][d[x][c]];
											l = l + a;
											n = i[l];
											o[n[N]] = o[n[h]] % n[g];
											l = l + a;
											n = i[l];
											e = n[f]
											o[e] = o[e](o[e + r])
											l = l + a;
											n = i[l];
											_ = n[w];
											S = o[_]
											for e = _ + 1, n[g] do
												S = S .. o[e];
											end;
											o[n[f]] = S;
											l = l + a;
											n = i[l];
											d = {
												o,
												n
											};
											d[r][d[x][b]] = d[a][d[x][M]] + d[r][d[x][s]];
											l = l + a;
											n = i[l];
											o[n[u]] = o[n[h]] % n[g];
											break;
										end
										while (e) / ((1558 + -64)) == 4040 do
											e = (729540)
											while d > (96 + -71) do
												e -= e
												o[n[b]] = o[n[h]][n[P]];
												break
											end
											while 772 == (e) / ((-#'test 123' + (1994 - 1041))) do
												if (o[n[k]] ~= o[n[P]]) then
													l = l + r;
												else
													l = n[c];
												end;
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								break;
							end
							while (e) / ((1544 - 817)) == 3286 do
								e = (2787840)
								while d <= (115 - 84) do
									e -= e
									e = (1800607)
									while d <= (46 + -18) do
										e -= e
										e = (2845384)
										while ((172 - 105) + -#"FBI is going to attack you now escape mf") < d do
											e -= e
											local a = y[n[U]];
											local d;
											local e = {};
											d = j({}, {
												__index = function(o, n)
													local e = e[n];
													return e[1][e[2]];
												end,
												__newindex = function(l, n, o)
													local e = e[n]
													e[1][e[2]] = o;
												end;
											});
											for d = 1, n[P] do
												l = l + r;
												local n = i[l];
												if n[(104 / 104)] == 55 then
													e[d - 1] = {
														o,
														n[B]
													};
												else
													e[d - 1] = {
														_,
														n[B]
													};
												end;
												m[#m + 1] = e;
											end;
											o[n[k]] = D(a, d, O);
											break
										end
										while (e) / (((-#"repeat that" + (914 + -94)) + -93)) == 3974 do
											O[n[c]] = o[n[k]];
											break
										end;
										break;
									end
									while (e) / ((7856 - 3967)) == 463 do
										e = (939930)
										while d <= ((((332 - 203) + -#"test 123") - 82) + -#"TacoTheDev") do
											e -= e
											if (o[n[t]] == n[M]) then
												l = l + r;
											else
												l = n[c];
											end;
											break;
										end
										while 1843 == (e) / (((105690 / 195) + -#[[xenny its znugget please respond]])) do
											e = (1548249)
											while (97 - 67) < d do
												e -= e
												local e = n[t]
												o[e] = o[e](C(o, e + a, n[s]))
												break
											end
											while (e) / ((3502 - 1795)) == 907 do
												O[n[c]] = o[n[b]];
												l = l + a;
												n = i[l];
												o[n[f]] = {};
												l = l + a;
												n = i[l];
												o[n[f]] = {};
												l = l + a;
												n = i[l];
												O[n[h]] = o[n[t]];
												l = l + a;
												n = i[l];
												o[n[b]] = O[n[s]];
												l = l + a;
												n = i[l];
												if (o[n[f]] == n[g]) then
													l = l + r;
												else
													l = n[h];
												end;
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								while 1452 == (e) / ((3919 - 1999)) do
									e = (249600)
									while (5742 / 174) >= d do
										e -= e
										e = (8764416)
										while (3776 / 118) < d do
											e -= e
											l = n[w];
											break
										end
										while 3804 == (e) / ((4723 - 2419)) do
											local e = {
												o,
												n
											};
											e[r][e[x][u]] = e[a][e[x][P]] + e[r][e[x][c]];
											break
										end;
										break;
									end
									while (e) / ((-61 + 829)) == 325 do
										e = (11031952)
										while (3400 / 100) >= d do
											e -= e
											_[n[w]] = o[n[k]];
											break;
										end
										while 2747 == (e) / ((927696 / 231)) do
											e = (1246784)
											while d > (5145 / 147) do
												e -= e
												o[n[N]] = _[n[c]];
												break
											end
											while 4048 == (e) / (((34452 / 108) + -#[[looadstring]])) do
												local d;
												local e;
												O[n[h]] = o[n[t]];
												l = l + a;
												n = i[l];
												o[n[N]] = O[n[h]];
												l = l + a;
												n = i[l];
												o[n[t]] = O[n[U]];
												l = l + a;
												n = i[l];
												e = n[u];
												d = o[n[h]];
												o[e + 1] = d;
												o[e] = d[n[P]];
												l = l + a;
												n = i[l];
												o[n[f]] = O[n[c]];
												l = l + a;
												n = i[l];
												o[n[N]] = n[h];
												l = l + a;
												n = i[l];
												o[n[f]] = n[U];
												l = l + a;
												n = i[l];
												o[n[u]] = n[U];
												l = l + a;
												n = i[l];
												e = n[N]
												o[e] = o[e](C(o, e + a, n[h]))
												l = l + a;
												n = i[l];
												o[n[N]] = (n[c] ~= 0);
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								break;
							end
							break;
						end
						break;
					end
					while 3136 == (e) / ((-#"everybody needs salvation" + (10467 / 9))) do
						e = (5252364)
						while (-#"repeat that" + (152 + -86)) >= d do
							e -= e
							e = (1752579)
							while ((9894 / (19788 / 102)) + -#[[weezer]]) >= d do
								e -= e
								e = (3622228)
								while (148 - 108) >= d do
									e -= e
									e = (3034296)
									while (-100 + 138) >= d do
										e -= e
										e = (10147944)
										while d > (-#[[amena jumping]] + (149 - 99)) do
											e -= e
											local e = n[t]
											o[e] = o[e](o[e + r])
											break
										end
										while 3282 == (e) / ((12368 / 4)) do
											local e = n[u]
											o[e] = o[e](o[e + r])
											break
										end;
										break;
									end
									while (e) / (((1241 + -78) + -#'azulx eats squids RUNNNN')) == 2664 do
										e = (1479291)
										while d > (-28 + (106 + -39)) do
											e -= e
											o[n[u]] = (n[s] ~= 0);
											break
										end
										while (e) / ((-92 + 851)) == 1949 do
											local e = n[t]
											o[e] = o[e](C(o, e + a, S))
											break
										end;
										break;
									end
									break;
								end
								while 2281 == (e) / ((-#"Fuck nigger wank shit dipshit cunt bullshit fuckyou hoe lol" + (-19 + 1666))) do
									e = (643269)
									while d <= (-#"Sub To BKProsYT" + (148 - 91)) do
										e -= e
										e = (8077860)
										while d > (10168 / (38440 / 155)) do
											e -= e
											o[n[u]] = o[n[h]] % n[g];
											break
										end
										while 3780 == (e) / ((-38 + 2175)) do
											local a = y[n[B]];
											local d;
											local e = {};
											d = j({}, {
												__index = function(o, n)
													local e = e[n];
													return e[1][e[2]];
												end,
												__newindex = function(l, o, n)
													local e = e[o]
													e[1][e[2]] = n;
												end;
											});
											for d = 1, n[M] do
												l = l + r;
												local n = i[l];
												if n[(89 - 88)] == 55 then
													e[d - 1] = {
														o,
														n[w]
													};
												else
													e[d - 1] = {
														_,
														n[w]
													};
												end;
												m[#m + 1] = e;
											end;
											o[n[u]] = D(a, d, O);
											break
										end;
										break;
									end
									while (e) / ((1174 - 595)) == 1111 do
										e = (10368)
										while (-62 + 105) >= d do
											e -= e
											o[n[N]][o[n[h]]] = o[n[M]];
											break;
										end
										while (e) / (((1284 / 12) - 89)) == 576 do
											e = (958188)
											while d > (-80 + 124) do
												e -= e
												local e = n[b]
												local l, n = p(o[e](C(o, e + 1, n[s])))
												S = n + e - 1
												local n = 0;
												for e = e, S do
													n = n + a;
													o[e] = l[n];
												end;
												break
											end
											while 1428 == (e) / ((-#[[pinkerton]] + (((-24 + 133991) + -#'require') / 197))) do
												do
													return
												end;
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								break;
							end
							while 2493 == (e) / (((1533 - 815) + -#"Nitro Activated")) do
								e = (1661496)
								while (-#[[free trojan]] + (117 + (-26 + -30))) >= d do
									e -= e
									e = (4531082)
									while ((4738 / 23) - 159) >= d do
										e -= e
										e = (1989455)
										while d > (211 - 165) do
											e -= e
											o[n[b]] = O[n[c]];
											break
										end
										while 1651 == (e) / (((-90 + 1309) + -#'Brizzy pro dev')) do
											o[n[b]] = o[n[w]][o[n[P]]];
											break
										end;
										break;
									end
									while (e) / ((3644 - 1858)) == 2537 do
										e = (1503685)
										while d <= ((-97 + (20240 / 115)) + -#[[black mess more like white mesa]]) do
											e -= e
											o[n[N]]();
											break;
										end
										while 967 == (e) / ((118180 / 76)) do
											e = (2856330)
											while d > ((173 - 99) + -#"everybody needs salvation") do
												e -= e
												if (o[n[b]] == o[n[g]]) then
													l = l + r;
												else
													l = n[h];
												end;
												break
											end
											while 2130 == (e) / ((1391 + -50)) do
												local e = n[k]
												o[e](o[e + r])
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								while (e) / ((188924 / 146)) == 1284 do
									e = (4066902)
									while (9204 / 177) >= d do
										e -= e
										e = (1136828)
										while (132 + -81) < d do
											e -= e
											o[n[t]]();
											break
										end
										while (e) / ((-109 + 417)) == 3691 do
											local e = n[k]
											o[e](o[e + r])
											break
										end;
										break;
									end
									while (e) / ((1347 + -24)) == 3074 do
										e = (2971122)
										while d <= (157 - 104) do
											e -= e
											local e = n[t]
											local l, n = p(o[e](C(o, e + 1, n[h])))
											S = n + e - 1
											local n = 0;
											for e = e, S do
												n = n + a;
												o[e] = l[n];
											end;
											break;
										end
										while 1199 == (e) / ((2561 + -83)) do
											e = (5402528)
											while d > (7884 / 146) do
												e -= e
												o[n[k]] = o[n[U]];
												break
											end
											while (e) / ((6377 - 3225)) == 1714 do
												o[n[b]] = n[B];
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								break;
							end
							break;
						end
						while 2106 == (e) / ((5006 - 2512)) do
							e = (58500)
							while d <= (15104 / 236) do
								e -= e
								e = (2380950)
								while (413 / 7) >= d do
									e -= e
									e = (1568120)
									while d <= (-#"xenny its znugget please respond" + (286 - 197)) do
										e -= e
										e = (10031098)
										while d > (169 - 113) do
											e -= e
											local l = n[t];
											local e = o[n[c]];
											o[l + 1] = e;
											o[l] = e[n[F]];
											break
										end
										while 2458 == (e) / ((48972 / 12)) do
											o[n[b]] = o[n[B]] - o[n[M]];
											break
										end;
										break;
									end
									while 796 == (e) / (((-62 + 2053) + -#'Oliwka Brazil To Szef')) do
										e = (1134243)
										while (4060 / 70) < d do
											e -= e
											o[n[f]] = D(y[n[s]], nil, O);
											break
										end
										while 737 == (e) / ((384750 / 250)) do
											local r;
											local d;
											local e;
											o[n[f]] = n[s];
											l = l + a;
											n = i[l];
											o[n[k]] = n[w];
											l = l + a;
											n = i[l];
											o[n[f]] = #o[n[U]];
											l = l + a;
											n = i[l];
											o[n[t]] = n[c];
											l = l + a;
											n = i[l];
											e = n[t];
											d = o[e]
											r = o[e + 2];
											if (r > 0) then
												if (d > o[e + 1]) then
													l = n[h];
												else
													o[e + 3] = d;
												end
											elseif (d < o[e + 1]) then
												l = n[s];
											else
												o[e + 3] = d;
											end
											break
										end;
										break;
									end
									break;
								end
								while (e) / ((1296 + -126)) == 2035 do
									e = (6528630)
									while (-#'911WasAnInsideJob' + (232 - 154)) >= d do
										e -= e
										e = (2207400)
										while (-#"no thanks" + (185 - 116)) < d do
											e -= e
											o[n[k]] = _[n[s]];
											l = l + a;
											n = i[l];
											o[n[b]] = #o[n[B]];
											l = l + a;
											n = i[l];
											_[n[U]] = o[n[k]];
											l = l + a;
											n = i[l];
											o[n[t]] = _[n[B]];
											l = l + a;
											n = i[l];
											o[n[b]] = #o[n[c]];
											l = l + a;
											n = i[l];
											_[n[c]] = o[n[f]];
											l = l + a;
											n = i[l];
											do
												return
											end;
											break
										end
										while 2600 == (e) / ((1786 - (103070 / 110))) do
											o[n[u]] = o[n[h]] - o[n[P]];
											break
										end;
										break;
									end
									while (e) / ((196908 / 122)) == 4045 do
										e = (10261675)
										while d <= (14322 / 231) do
											e -= e
											local e = n[f];
											local l = o[n[h]];
											o[e + 1] = l;
											o[e] = l[n[M]];
											break;
										end
										while (e) / ((180133 / 61)) == 3475 do
											e = (4837227)
											while d > (-#'cock in my ass' + (-96 + 173)) do
												e -= e
												do
													return
												end;
												break
											end
											while (e) / ((-61 + 3144)) == 1569 do
												o[n[k]] = (n[B] ~= 0);
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								break;
							end
							while 500 == (e) / ((-#[[black mess more like white mesa]] + (323 - 175))) do
								e = (10079088)
								while d <= (-26 + 95) do
									e -= e
									e = (98420)
									while d <= (-#"everybody needs salvation" + (149 + -58)) do
										e -= e
										e = (5899127)
										while d > (151 - 86) do
											e -= e
											o[n[u]] = D(y[n[U]], nil, O);
											break
										end
										while 2249 == (e) / ((-#'gaymen' + (2713 + -84))) do
											local l = n[w];
											local e = o[l]
											for n = l + 1, n[v] do
												e = e .. o[n];
											end;
											o[n[t]] = e;
											break
										end;
										break;
									end
									while 37 == (e) / ((383040 / 144)) do
										e = (3296063)
										while (7370 / 110) >= d do
											e -= e
											o[n[k]] = o[n[B]];
											break;
										end
										while 3691 == (e) / (((150350 / 155) + -77)) do
											e = (8056776)
											while (-#"dont use it anymore" + (275 - 188)) < d do
												e -= e
												o[n[t]] = {};
												break
											end
											while 2184 == (e) / ((-76 + 3765)) do
												o[n[u]] = o[n[U]] % n[P];
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								while 2832 == (e) / (((60860 / 17) + -#"iPipeh iam u Best Fan")) do
									e = (1808252)
									while d <= (-#"Dick" + (-44 + 119)) do
										e -= e
										e = (4885617)
										while (140 / 2) < d do
											e -= e
											local e = n[u]
											o[e] = o[e](C(o, e + a, S))
											break
										end
										while 1419 == (e) / (((-79 + 3527) + -#"tonka")) do
											o[n[N]] = (n[h] ~= 0);
											l = l + r;
											break
										end;
										break;
									end
									while (e) / ((7141 - 3623)) == 514 do
										e = (7029465)
										while d <= ((2550 / 30) + -#"fish was here") do
											e -= e
											o[n[u]] = #o[n[h]];
											break;
										end
										while (e) / ((6404 - 3239)) == 2221 do
											e = (6644190)
											while d > (-#"ez monke" + (-58 + 139)) do
												e -= e
												o[n[k]] = O[n[c]];
												break
											end
											while 2030 == (e) / ((-#"IPIPEH ILOVE YOU AAAAA" + (3364 + -69))) do
												if (o[n[f]] == n[P]) then
													l = l + r;
												else
													l = n[U];
												end;
												break
											end;
											break;
										end
										break;
									end
									break;
								end
								break;
							end
							break;
						end
						break;
					end
					l += r
				end;
			end);
		end;
		return D(I(), {}, J())()
	end)
	_msec({
		[(280 - (31310 / 202))] = '\115\116' .. (function(e)
			return (e and '              ') or '\114\105' or '\120\58'
		end)((-#[[iPipeh is Winner]] + (-103 + 124)) == (129 - 123)) .. '\110g',
		["               "] = '\108\100' .. (function(e)
			return (e and '        ​  ') or '\101\120' or '\119\111'
		end)(((121 - 83) - 33) == (76 + -70)) .. '\112',
		["   ​            "] = (function(e)
			return (e and '          ​    ') and '\98\121' or '\100\120'
		end)((-#[[weezer]] + (141 - 130)) == (85 - 80)) .. '\116\101',
		["         ​        "] = '\99' .. (function(e)
			return (e and ' ​       ') and '\90\19\157' or '\104\97'
		end)(((-143 + 23) + 125) == (27 + -24)) .. '\114',
		[(-#[[ILoveBlowJobs]] + (612 + -76))] = '\116\97' .. (function(e)
			return (e and '                   ') and '\64\113' or '\98\108'
		end)((-40 + 46) == ((271 - 183) - 83)) .. '\101',
		["                   "] = (function(e)
			return (e and '                ') or '\115\117' or '\78\107'
		end)(((100 / 10) + -#[[Factual]]) == (4247 / 137)) .. '\98',
		[" ​​     "] = '\99\111' .. (function(e)
			return (e and '             ') and '\110\99' or '\110\105\103\97'
		end)((620 / 20) == (1984 / 64)) .. '\97\116',
		[(50100 / 75)] = (function(e, n)
			return (e and '             ') and '\48\159\158\188\10' or '\109\97'
		end)((-#"cock in my ass" + ((-5412 / 123) + 63)) == (354 / 59)) .. '\116\104',
		[((2908 - 1504) + -20)] = (function(e, n)
			return ((775 / 155) == (104 + -101) and '\48' .. '\195' or e .. ((not'\20\95\69' and '\90' .. '\180' or n))) or '\199\203\95'
		end),
		["         "] = '\105\110' .. (function(e, n)
			return (e and '        ') and '\90\115\138\115\15' or '\115\101'
		end)((-#[[Candyman was here]] + (130 + ((-119 + 23) + -#"Rivers Cuomo"))) == ((128 - 76) + -#[[Two trucks having sex]])) .. '\114\116',
		["            ​  "] = '\117\110' .. (function(e, n)
			return (e and '  ​     ') or '\112\97' or '\20\38\154'
		end)((-#"iPipeh Is My God" + (-62 + 83)) == (-#'iam u Furry iPipeh' + (-42 + 91))) .. '\99\107',
		["           "] = '\115\101' .. (function(e)
			return (e and '      ​       ​ ') and '\110\112\99\104' or '\108\101'
		end)((116 - 111) == (157 - 126)) .. '\99\116',
		["           ​  ​    "] = '\116\111\110' .. (function(e, n)
			return (e and ' ​         ') and '\117\109\98' or '\100\97\120\122'
		end)((-99 + (10816 / 104)) == ((648 / 27) + -#[[I like gargling cum]])) .. '\101\114'
	}, {
		["                "] = ((getfenv))
	}, ((getfenv))())
end)()