getglobal Workspace
getfield -1 Remote
getfield -1 TeamEvent
getfield -1 FireServer
pushvalue -2
pushstring Royal purple
pcall 2 1 0
