# I-Quit-GT-Modding.
I quit, Sorry.
my last vid on Gorilla Tag
How To Get Un IP Banned - https://youtu.be/GUikScgiOJ0
